<?php

include("classes/autoload.php");

$login = new Login();
$user_data = $login->check_login($_SESSION['shwag_userid']);
$USER = $user_data;
$id = $_SESSION['shwag_userid'];

$post = new Post();
$about = $post->get_about_info($id);

if (!$about) {
	$lives_in = "";
	$profession = "";
	$company_name = "";
	$fun_quote = "";
	$rel_status = "";
}else{
	$lives_in = $about['lives_in'];
	$profession = $about['profession'];
	$company_name = $about['company_name'];
	$fun_quote = $about['fun_quote'];
	$rel_status = $about['rel_status'];
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
	{

		if ($about == "") {
			$post = new Post();
			$post->add_new_edit_data($_POST,$id);
			
			header("Location: about.php");
			die;
		}else{
			$post = new Post();
			$post->update_edit_data($_POST,$id);
			
			header("Location: about.php");
			die;
		}

	}

?>


<html>

 <head>

 <title>SHWAG | About</title>

 </head>

 <style type="text/css">
	#blue_bar{
		height: 50px;
		background-color: #ED3782;
		color: whitesmoke;
	}

	#search_box{
		width: 400px;
		height: 20px;
		font-family: courier new;
		border-radius: 4px;
		padding: 4px;
		font-size: 14px;
		background-image: url(search.png);
		background-repeat: no-repeat;
		background-position: right;
	}

	#heading{
		height: 100px;
		background-color: #ED3782;
		color: whitesmoke;
		padding: 4px;
	}

	#login_button{
		background-color: #A8275C;
		width: 70px;
		text-align: center;
		padding: 4px;
		border-radius: 4px;
		float: right;
		font-weight: bold;
	}

	#signup_bar{
		background-color: whitesmoke;
		width: 800px;
		height: 500px;
		margin: auto;
		margin-top: 50px;
		padding: 10px;
		padding-top: 50px;
		text-align: center;
		font-weight: bold;
	}

	#text{
		height: 40px;
		width: 300px;
		border-radius: 4px;
		border: solid 1px #aaa;
		padding: 4px;
		font-size: 14px;
		font-family: courier new
	}

	#button{
		height: 30px;
		font-weight: bold;
		background-color: #ED3782;
		border-radius: 4px;
		border: solid 1px;
		font-size: 14px;
		font-family: courier new
	}

 </style>

 <body style="font-family: courier new;background-color: C2C2C2;">

 	<?php include("header.php"); ?>
 	
	<div id="signup_bar" style="text-align: left;">
	About <?php echo $USER['first_name'] ?> <br><br>
	<form method="post" action="">

		First Name <input value="<?php echo $USER['first_name'] ?>" name="first_name" type="text" id ="text" placeholder="First Name"><br>
		Last Name <input value="<?php echo $USER['last_name'] ?>" name="last_name" type="text" id ="text" placeholder="Last Name"><br>
		Lives in <input value="<?php echo $lives_in ?>" name="lives_in" type="text" id ="text" placeholder="Lives In"><br>
		Profession <input value="<?php echo $profession ?>" name="profession" type="text" id ="text" placeholder="Profession"><br>
		Works at <input value="<?php echo $company_name ?>" name="company_name" type="text" id ="text" placeholder="Company Name"><br>
		Describe Yourself <input value="<?php echo $fun_quote ?>" name="fun_quote" type="text" id ="text" placeholder="Describe yourself"><br>
		Relationship Status <input value="<?php echo $rel_status ?>" name="rel_status" type="text" id ="text" placeholder="Relationship Status"><br><br><br>
		
		<input type="submit" id ="button" value="Save">

	</form>
	</div>
 	
 </body>

</html>