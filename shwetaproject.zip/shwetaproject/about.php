<?php

include("classes/autoload.php");

$login = new Login();
$user_data = $login->check_login($_SESSION['shwag_userid']);
$USER = $user_data;
$id = $_SESSION['shwag_userid'];

$post = new Post();
$about = $post->get_about_info($id);

if (!$about) {
	$lives_in = "";
	$profession = "";
	$company_name = "";
	$fun_quote = "";
	$rel_status = "";
}else{
	$lives_in = $about['lives_in'];
	$profession = $about['profession'];
	$company_name = $about['company_name'];
	$fun_quote = $about['fun_quote'];
	$rel_status = $about['rel_status'];
}

?>

<html>

 <head>

 <title>SHWAG | About</title>

 </head>

 <style type="text/css">
	#blue_bar{
		height: 50px;
		background-color: #ED3782;
		color: whitesmoke;
	}

	#search_box{
		width: 400px;
		height: 20px;
		font-family: courier new;
		border-radius: 4px;
		padding: 4px;
		font-size: 14px;
		background-image: url(search.png);
		background-repeat: no-repeat;
		background-position: right;
	}

	#heading{
		height: 100px;
		background-color: #ED3782;
		color: whitesmoke;
		padding: 4px;
	}

	#login_button{
		background-color: #A8275C;
		width: 70px;
		text-align: center;
		padding: 4px;
		border-radius: 4px;
		float: right;
		font-weight: bold;
	}

	#signup_bar{
		background-color: whitesmoke;
		width: 800px;
		height: 500px;
		margin: auto;
		margin-top: 50px;
		padding: 10px;
		padding-top: 50px;
		text-align: center;
		font-weight: bold;
	}

	#text{
		height: 40px;
		width: 300px;
		border-radius: 4px;
		border: solid 1px #aaa;
		padding: 4px;
		font-size: 14px;
		font-family: courier new
	}

	#button{
		height: 30px;
		font-weight: bold;
		background-color: #ED3782;
		border-radius: 4px;
		border: solid 1px;
		font-size: 14px;
		font-family: courier new
	}

 </style>

 <body style="font-family: courier new;background-color: C2C2C2;">

 	<?php include("header.php"); ?>
 	
	<div id="signup_bar">
	About <?php echo $USER['first_name'] ?> <br><br>

	<span style="font-weight: normal;">
		I am <?php echo $USER['first_name'] . ' ' . $USER['last_name'] ?><br>
		Lives in <?php echo $lives_in ?><br>
		Profession: <?php echo $profession ?><br>
		Company: <?php echo $company_name ?><br>
		About yourself: <?php echo $fun_quote ?><br>
		Relationship Status: <?php echo $rel_status ?><br><br><br>
		</span>
		
		<a href="about_edit.php" style="text-decoration: none"> Edit </div></a>

	</div>
 	
 </body>

</html>